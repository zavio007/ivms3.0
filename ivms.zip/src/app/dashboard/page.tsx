"use client"
import React from 'react';
import AppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
import Container from '@mui/material/Container';
import Grid from '@mui/material/Grid';
import SwipeableTemporaryDrawer from '../components/swipeRight/page';

const Dashboard = () => {
  return (
    <div>
      {/* App Bar */}
      <AppBar position="static">
        <Toolbar>
          <Typography variant="h6">Dashboard</Typography>
          <div className=''></div>
        </Toolbar>
      </AppBar>
<SwipeableTemporaryDrawer/>
      {/* Main Content */}
      <Container>
        <Grid container spacing={3}>
          {/* Dashboard Widgets */}
          <Grid item xs={12} sm={6} md={4}>
            {/* Your first widget content */}
          </Grid>
          <Grid item xs={12} sm={6} md={4}>
            {/* Your second widget content */}
          </Grid>
          <Grid item xs={12} sm={6} md={4}>
            {/* Your third widget content */}
          </Grid>
        </Grid>
      </Container>
    </div>
  );
};

export default Dashboard;
